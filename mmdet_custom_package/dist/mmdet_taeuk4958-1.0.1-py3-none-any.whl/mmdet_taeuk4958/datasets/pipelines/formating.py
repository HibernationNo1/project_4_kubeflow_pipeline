# Copyright (c) OpenMMLab. All rights reserved.
# flake8: noqa
import warnings

from .formatting import *

warnings.warn('DeprecationWarning: mmdet_taeuk4958.datasets.pipelines.formating will be '
              'deprecated, please replace it with '
              'mmdet_taeuk4958.datasets.pipelines.formatting.')
